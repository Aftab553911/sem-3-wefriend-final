﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using sem3Final.DL;
using sem3Final.BL;
using System.Windows.Forms;

namespace sem3Final
{
    public partial class sign_up_new_user : Form
    {
        string path = "sem3Final.txt";
        public sign_up_new_user()
        {
            InitializeComponent();
            comboBox1.Items.Add("Lahore");
            comboBox1.Items.Add("Multan");
            comboBox1.Items.Add("Karachi");
            comboBox1.Items.Add("Peshawar");
            comboBox1.Items.Add("Islamabad");
            comboBox1.Items.Add("Mia Chanu");
            comboBox1.Items.Add("Faisalabad");
            comboBox1.Items.Add("Miawali");
            comboBox1.Items.Add("Rahim Yar Khan");
            comboBox1.Items.Add("Sahiwal");
            comboBox1.Items.Add("Abbatabad");
        }

        private void panel1_Paint(object sender, PaintEventArgs e)
        {
            
        
        }

        private void next_btn_Click(object sender, EventArgs e)
        {
             string name=name_textbox.Text;
             string id=id_textbox.Text;
             string phone_number=phone_textbox.Text;
            string location = comboBox1.Text;
            string gender;
            if (name_textbox.Text == "" || id_textbox.Text == "" || phone_textbox.Text == "" || comboBox1.Text == "")
            {
             
                MessageBox.Show("Please! Fill All Credentials :)");
            }
            else
            {

                if (female_rb.Checked == true)
                {
                    gender = female_rb.Text;

                }
                else
                {
                    gender = male_rb.Text;
                }
                string user_type;
                if (admin_rad_btn.Checked == true)
                {
                    user_type = admin_rad_btn.Text;

                }
                else
                {
                    user_type = user_rad_btn.Text;
                }
                user_bl A = new user_bl(name, id, phone_number, location, gender, user_type);
                user_dl.users_list.Add(A);
                MessageBox.Show("successfully added ");
                user_dl.WriteFile(A, path);
                this.Hide();
                sign_in_up foam = new sign_in_up();
                foam.Show();
            }


}

        private void radioButton1_CheckedChanged(object sender, EventArgs e)
        {

        }

        private void male_rb_CheckedChanged(object sender, EventArgs e)
        {

        }

        private void back_btn_Click(object sender, EventArgs e)
        {
            this.Hide();
            sign_in_up n = new sign_in_up();
            n.Show();
        }

        private void location_combo_Click(object sender, EventArgs e)
        {

        }

        private void guna2PictureBox1_Click(object sender, EventArgs e)
        {

        }

        private void guna2TextBox1_TextChanged(object sender, EventArgs e)
        {

        }
    }
    }

