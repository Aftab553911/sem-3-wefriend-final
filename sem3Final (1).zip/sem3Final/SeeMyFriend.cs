﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using sem3Final.BL;
using sem3Final.DL;

namespace sem3Final
{
    public partial class SeeMyFriend : Form
    {
        user_bl new_user;
        public SeeMyFriend(user_bl new_user)
        {
            InitializeComponent();
            this.new_user = new_user;
        }

        private void SeeMyFriend_Load(object sender, EventArgs e)
        {
            MessageBox.Show(new_user.Id);
            MessageBox.Show(user_dl.counter+""+user_dl.counter1);
            List<user_bl> n_list = new List<user_bl>();
            DataTable table = new DataTable();
            table.Columns.Add("Name", typeof(string));
            table.Columns.Add("id", typeof(string));
            table.Columns.Add("phone Number", typeof(string));
            table.Columns.Add("Location", typeof(string));
            table.Columns.Add("Gender", typeof(string));
            table.Columns.Add("user type", typeof(string));
            foreach (KeyValuePair<user_bl,List<user_bl>> user in user_dl.main_dict)
            {
                if(user.Key.Id == new_user.Id)
                {
                    for(int x = 0; x < user.Value.Count; x++)
                    {
                        table.Rows.Add(user.Value[x].Name,user.Value[x].Id, user.Value[x].Phone_number, user.Value[x].Location, user.Value[x].Gender, user.Value[x].User_type);
                    }
                    dataGV.DataSource = table;
                   
                }
            }
        }

        private void guna2DataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void panel1_Paint(object sender, PaintEventArgs e)
        {

        }

        private void guna2GradientButton1_Click(object sender, EventArgs e)
        {
            this.Hide();
            Admin_login f = new Admin_login(new_user);
            f.Show();
        }
    }
}
