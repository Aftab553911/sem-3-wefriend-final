﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;
using sem3Final.BL;
using System.Data.SqlClient;
using System.Data;

namespace sem3Final.DL
{
  public class user_dl
    {
        public static string counter="";
        public static string counter1="";
        public static string  Musers_path = "sem3Final.txt";
        public static Dictionary<user_bl, List<user_bl>> main_dict = new Dictionary<user_bl, List<user_bl>>();
        public static Dictionary<user_bl, List<user_bl>> send_request_Dict = new Dictionary<user_bl, List<user_bl>>();
        public static List<user_bl> users_list = new List<user_bl>();

        /*for write data into file*/
        //  load server data
        public static void re_write_request(string path)
        {
            string path1 = path;
            foreach(KeyValuePair<user_bl,List<user_bl>> friend in send_request_Dict)
            {
                user_bl temp1 = new user_bl();
                temp1 = friend.Key;
                counter = friend.Key.Id;
                foreach(user_bl user in friend.Value)
                {
                    user_bl temp2 = new user_bl();
                    temp2 = user;
                    s_r_friend_request_write_file(temp1, temp2);
                }
            }
            
        }
      
        public static void s_r_friend_request_write_file(user_bl s_user, user_bl r_user)
        {
            string path = "";
            path = "send_receive_friends_data.txt";

            StreamWriter file = new StreamWriter(path, true);
            file.WriteLine(s_user.Name + "," + s_user.Id + "," + s_user.Phone_number + "," + s_user.Location + "," + s_user.Gender + "," + s_user.User_type + "," + r_user.Name + "," + r_user.Id + "," + r_user.Phone_number + "," + r_user.Location + "," + r_user.Gender + "," + r_user.User_type);
            file.Flush();
            file.Close();

        }
        public static void main_graph_write_data(user_bl s_user, user_bl r_user)
        {
            string path = "";
            path = "main_graph.txt";
            StreamWriter file = new StreamWriter(path, true);
            file.WriteLine(s_user.Name + "," + s_user.Id + "," + s_user.Phone_number + "," + s_user.Location + "," + s_user.Gender + "," + s_user.User_type + "," + r_user.Name + "," + r_user.Id + "," + r_user.Phone_number + "," + r_user.Location + "," + r_user.Gender + "," + r_user.User_type);
            file.Flush();
            file.Close();

        }
        public static void s_r_friend_request_load_file()
        {
            StreamReader account_read = new StreamReader("send_receive_friends_data.txt");

            string record;
            string name;
            string id;
            string gender;
            string phone_number;
            string location;
            string user_type;
            while ((record = account_read.ReadLine()) != null)
            {
                name = PARSE_RECORD(record, 0);
                //PARSE_FUNCTION(ref record,accountant_name,father_name,cnic,source_income,ref count);
                id = PARSE_RECORD(record, 1);
                phone_number = PARSE_RECORD(record, 2);
                location = PARSE_RECORD(record, 3);
                gender = PARSE_RECORD(record, 4);
                user_type = PARSE_RECORD(record, 5);
                user_bl sender = new user_bl(name, id, phone_number, location, gender, user_type);
                name = PARSE_RECORD(record, 6);
                //PARSE_FUNCTION(ref record,accountant_name,father_name,cnic,source_income,ref count);
                id = PARSE_RECORD(record, 7);
                phone_number = PARSE_RECORD(record,8);
                location = PARSE_RECORD(record, 9);
                gender = PARSE_RECORD(record, 10);
                user_type = PARSE_RECORD(record,11);
                user_bl receiver = new user_bl(name, id, phone_number, location, gender, user_type);
                //       if (!main_dict.ContainsKey(sender))
                //       main_dict.Add(sender, new List<user_bl>());
                //if (!main_dict.ContainsKey(receiver))
                //         main_dict.Add(receiver, new List<user_bl>());
                //    main_dict[receiver].Add(sender);
                //  main_dict[sender].Add(receiver);
                //  users_list.Add(A);
                if (!user_dl.send_request_Dict.ContainsKey(receiver))
                {
                    user_dl.send_request_Dict.Add(receiver, new List<user_bl>());
                    // MessageBox.Show("successfully request send");

                }
                if (!user_dl.send_request_Dict.ContainsKey(sender))
                {
                    user_dl.send_request_Dict.Add(sender, new List<user_bl>());
                    // MessageBox.Show("successfully request send");
                }
                user_dl.send_request_Dict[receiver].Add(sender);


            }
        }
        public static void main_graph_load_file()
        {
            StreamReader account_read = new StreamReader("main_graph.txt");
             
            string record;
            string name;
            string id;
            string gender;
            string phone_number;
            string location;
            string user_type;
            while ((record = account_read.ReadLine()) != null)
            {
                name = PARSE_RECORD(record, 0);
                //PARSE_FUNCTION(ref record,accountant_name,father_name,cnic,source_income,ref count);
                id = PARSE_RECORD(record, 1);
                phone_number = PARSE_RECORD(record, 2);
                location = PARSE_RECORD(record, 3);
                gender = PARSE_RECORD(record, 4);
                user_type = PARSE_RECORD(record, 5);
                user_bl sender = new user_bl(name, id, phone_number, location, gender, user_type);
                name = PARSE_RECORD(record, 6);
                //PARSE_FUNCTION(ref record,accountant_name,father_name,cnic,source_income,ref count);
                id = PARSE_RECORD(record, 7);
                phone_number = PARSE_RECORD(record,8);
                location = PARSE_RECORD(record, 9);
                gender = PARSE_RECORD(record, 10);
                user_type = PARSE_RECORD(record,11);
                user_bl receiver = new user_bl(name, id, phone_number, location, gender, user_type);
               
                if (!main_dict.ContainsKey(sender)) 
                {
                  main_dict.Add(sender, new List<user_bl>());
                }
                if (!main_dict.ContainsKey(receiver))
                {

                  main_dict.Add(receiver, new List<user_bl>());
                }
                counter = receiver.Name;
                counter1 = sender.Name;
                main_dict[receiver].Add(sender);
                main_dict[sender].Add(receiver);
            }
        }
        public static void s_r_friend_request_delete(user_bl sender, user_bl receiver)
        {
            foreach(KeyValuePair<user_bl,List<user_bl>> friend in send_request_Dict)
            { 
                if(friend.Key.Id == sender.Id)
                {
                    for(int i=0;i<friend.Value.Count;i++)
                    {
                        if(friend.Value[i].Id == receiver.Id)
                        {
                            friend.Value.RemoveAt(i);
                        }
                    }
                }
            }
            foreach (KeyValuePair<user_bl, List<user_bl>> friend in send_request_Dict)
            {
                if (friend.Key.Id == receiver.Id)
                {
                    for (int i = 0; i < friend.Value.Count; i++)
                    { 
                        if (friend.Value[i].Id == sender.Id)
                        {
                            friend.Value.RemoveAt(i);
                        }
                    }
                }
            }
        }
        public static void Save_Data(string path,user_bl n,user_bl j)
        {
            StreamWriter file = new StreamWriter(path, true);
            file.WriteLine(j+","+n.Name + "," + n.Id);
            file.Flush();
            file.Close();
        }
        public static void WriteFile(user_bl user,string path)
        {
            StreamWriter file = new StreamWriter(path, true);
            file.WriteLine(user.Name + "," + user.Id +  "," + user.Phone_number + "," + user.Location+ "," + user.Gender + "," +user.User_type);
            file.Flush();
            file.Close();
        }
        public static void send_request_write_data(user_bl user,string path)
        {
            StreamWriter file = new StreamWriter(path, true);
            file.WriteLine(user.Name + "," + user.Id + "," + user.Phone_number + "," + user.Location + "," + user.Gender + "," + user.User_type);
            file.Flush();
            file.Close();
        }
        public static void send_request_Load_data()
        {
            StreamReader a = new StreamReader("send_request_file.txt");
            int count = 0;
            string record;
            string name;
            string id;
            string gender;
            string phone_number;
            string location;
            string user_type;
            user_bl key=null;
            while ((record = a.ReadLine()) != null)
            {
                name = PARSE_RECORD(record, 0);
                //PARSE_FUNCTION(ref record,accountant_name,father_name,cnic,source_income,ref count);
                id = PARSE_RECORD(record, 1);
                phone_number = PARSE_RECORD(record, 2);
                location = PARSE_RECORD(record, 3);
                gender = PARSE_RECORD(record, 4);
                user_type = PARSE_RECORD(record, 5);

                user_bl A = new user_bl(name, id, phone_number, location, gender, user_type);
                if (count == 0)
                {
                    key = A;
                    count++;
                }
                else
                {
                    send_request_Dict[key].Add(A);
                }
            }

            a.Close();
        }
        static string PARSE_RECORD(string record, int field)
        {
            int comma = 0;
            string item = "";
            for (int a = 0; a < record.Length; a++)
            {
                if (record[a] == ',')
                {
                    comma++;
                }
                else if (comma == field)
                {
                    item = item + record[a];
                }
            }
            return item;
        }
        public static user_bl check_user(string user_name,string password,string user_type)
        {
             
            for (int x = 0; x < users_list.Count; x++)
            {
                if (user_name == users_list[x].Name && password == users_list[x].Id && user_type == users_list[x].User_type)
                {
                    return users_list[x];
                }
            }
            return null;

        }
        public static void load_users()
        {
            users_list.Clear();
            StreamReader account_read = new StreamReader(Musers_path);

            string record;
            string name;
            string id;
            string gender;
            string phone_number;
            string location;
            string user_type;
            while ((record = account_read.ReadLine()) != null)
            {
                name = PARSE_RECORD(record, 0);
                //PARSE_FUNCTION(ref record,accountant_name,father_name,cnic,source_income,ref count);
                id = PARSE_RECORD(record, 1);
                phone_number = PARSE_RECORD(record, 2);
                location = PARSE_RECORD(record, 3);
                 gender= PARSE_RECORD(record, 4);
                user_type = PARSE_RECORD(record, 5);
                
                user_bl A = new user_bl(name, id,  phone_number, location, gender, user_type);
               users_list.Add(A);
              
}

            account_read.Close();
        }
    }  
}
