﻿
namespace sem3Final
{
    partial class Admin_login
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Admin_login));
            this.imageList1 = new System.Windows.Forms.ImageList(this.components);
            this.admin_panel = new System.Windows.Forms.Panel();
            this.guna2ImageButton1 = new Guna.UI2.WinForms.Guna2ImageButton();
            this.dash_board_panel_1 = new System.Windows.Forms.Panel();
            this.view_profile_panel_2 = new System.Windows.Forms.Panel();
            this.update_user_panel_3 = new System.Windows.Forms.Panel();
            this.frien_resuestsss_panel_5 = new System.Windows.Forms.Panel();
            this.map_panel_6 = new System.Windows.Forms.Panel();
            this.guna2find = new Guna.UI2.WinForms.Guna2CircleButton();
            this.webBrowser1 = new System.Windows.Forms.WebBrowser();
            this.guna2Destination = new Guna.UI2.WinForms.Guna2TextBox();
            this.Destination = new Guna.UI2.WinForms.Guna2HtmlLabel();
            this.guna2Location = new Guna.UI2.WinForms.Guna2TextBox();
            this.guna2HtmlLabel1 = new Guna.UI2.WinForms.Guna2HtmlLabel();
            this.send_reuest_btn = new System.Windows.Forms.Button();
            this.ADD_FRIEND_SEARCH_BTN = new System.Windows.Forms.Button();
            this.add_friend_back_btn = new System.Windows.Forms.Button();
            this.dataGridView1 = new System.Windows.Forms.DataGridView();
            this.label9 = new System.Windows.Forms.Label();
            this.add_friend_tbox = new System.Windows.Forms.TextBox();
            this.search_panel_4 = new System.Windows.Forms.Panel();
            this.insode_search_tb_layout = new System.Windows.Forms.TableLayoutPanel();
            this.tableLayoutPanel2 = new System.Windows.Forms.TableLayoutPanel();
            this.id_Box = new System.Windows.Forms.TextBox();
            this.searchButton = new System.Windows.Forms.Button();
            this.dataGV = new System.Windows.Forms.DataGridView();
            this.panel6 = new System.Windows.Forms.Panel();
            this.button2 = new System.Windows.Forms.Button();
            this.pro_name_txtbox = new System.Windows.Forms.TextBox();
            this.pro_phone_txtbox = new System.Windows.Forms.TextBox();
            this.pro_locat_txtbox = new System.Windows.Forms.TextBox();
            this.label5 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.profile_back = new System.Windows.Forms.Button();
            this.panel5 = new System.Windows.Forms.Panel();
            this.panel3 = new System.Windows.Forms.Panel();
            this.active_user_text = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.button1 = new System.Windows.Forms.Button();
            this.panel2 = new System.Windows.Forms.Panel();
            this.msg_btn = new Guna.UI2.WinForms.Guna2GradientButton();
            this.guna2GradientButton2 = new Guna.UI2.WinForms.Guna2GradientButton();
            this.guna2GradientButton1 = new Guna.UI2.WinForms.Guna2GradientButton();
            this.loc_map_btn = new System.Windows.Forms.Button();
            this.search_btn = new System.Windows.Forms.Button();
            this.friend_request_btn = new System.Windows.Forms.Button();
            this.add_friend_btn = new System.Windows.Forms.Button();
            this.view_profile = new System.Windows.Forms.Button();
            this.dashboard_btn = new System.Windows.Forms.Button();
            this.title_panel = new System.Windows.Forms.Panel();
            this.label1 = new System.Windows.Forms.Label();
            this.admin_panel.SuspendLayout();
            this.dash_board_panel_1.SuspendLayout();
            this.view_profile_panel_2.SuspendLayout();
            this.update_user_panel_3.SuspendLayout();
            this.frien_resuestsss_panel_5.SuspendLayout();
            this.map_panel_6.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
            this.search_panel_4.SuspendLayout();
            this.insode_search_tb_layout.SuspendLayout();
            this.tableLayoutPanel2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGV)).BeginInit();
            this.panel6.SuspendLayout();
            this.panel3.SuspendLayout();
            this.panel2.SuspendLayout();
            this.title_panel.SuspendLayout();
            this.SuspendLayout();
            // 
            // imageList1
            // 
            this.imageList1.ColorDepth = System.Windows.Forms.ColorDepth.Depth8Bit;
            this.imageList1.ImageSize = new System.Drawing.Size(16, 16);
            this.imageList1.TransparentColor = System.Drawing.Color.Transparent;
            // 
            // admin_panel
            // 
            this.admin_panel.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.admin_panel.Controls.Add(this.guna2ImageButton1);
            this.admin_panel.Controls.Add(this.dash_board_panel_1);
            this.admin_panel.Controls.Add(this.panel2);
            this.admin_panel.Controls.Add(this.title_panel);
            this.admin_panel.Location = new System.Drawing.Point(0, 0);
            this.admin_panel.Name = "admin_panel";
            this.admin_panel.Size = new System.Drawing.Size(1058, 551);
            this.admin_panel.TabIndex = 0;
            // 
            // guna2ImageButton1
            // 
            this.guna2ImageButton1.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("guna2ImageButton1.BackgroundImage")));
            this.guna2ImageButton1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.guna2ImageButton1.CheckedState.ImageSize = new System.Drawing.Size(64, 64);
            this.guna2ImageButton1.HoverState.ImageSize = new System.Drawing.Size(64, 64);
            this.guna2ImageButton1.Image = ((System.Drawing.Image)(resources.GetObject("guna2ImageButton1.Image")));
            this.guna2ImageButton1.ImageOffset = new System.Drawing.Point(0, 0);
            this.guna2ImageButton1.ImageRotate = 0F;
            this.guna2ImageButton1.Location = new System.Drawing.Point(3, 3);
            this.guna2ImageButton1.Name = "guna2ImageButton1";
            this.guna2ImageButton1.PressedState.ImageSize = new System.Drawing.Size(64, 64);
            this.guna2ImageButton1.Size = new System.Drawing.Size(163, 54);
            this.guna2ImageButton1.TabIndex = 4;
            this.guna2ImageButton1.Click += new System.EventHandler(this.guna2ImageButton1_Click);
            // 
            // dash_board_panel_1
            // 
            this.dash_board_panel_1.BackColor = System.Drawing.SystemColors.ControlDarkDark;
            this.dash_board_panel_1.BackgroundImage = global::sem3Final.Properties.Resources.bk;
            this.dash_board_panel_1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.dash_board_panel_1.Controls.Add(this.view_profile_panel_2);
            this.dash_board_panel_1.Controls.Add(this.panel3);
            this.dash_board_panel_1.Controls.Add(this.button1);
            this.dash_board_panel_1.Location = new System.Drawing.Point(172, 71);
            this.dash_board_panel_1.Name = "dash_board_panel_1";
            this.dash_board_panel_1.Size = new System.Drawing.Size(860, 458);
            this.dash_board_panel_1.TabIndex = 3;
            this.dash_board_panel_1.Paint += new System.Windows.Forms.PaintEventHandler(this.dash_board_panel_Paint);
            // 
            // view_profile_panel_2
            // 
            this.view_profile_panel_2.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.view_profile_panel_2.Controls.Add(this.update_user_panel_3);
            this.view_profile_panel_2.Controls.Add(this.pro_name_txtbox);
            this.view_profile_panel_2.Controls.Add(this.pro_phone_txtbox);
            this.view_profile_panel_2.Controls.Add(this.pro_locat_txtbox);
            this.view_profile_panel_2.Controls.Add(this.label5);
            this.view_profile_panel_2.Controls.Add(this.label6);
            this.view_profile_panel_2.Controls.Add(this.label7);
            this.view_profile_panel_2.Controls.Add(this.profile_back);
            this.view_profile_panel_2.Controls.Add(this.panel5);
            this.view_profile_panel_2.Location = new System.Drawing.Point(0, 0);
            this.view_profile_panel_2.Name = "view_profile_panel_2";
            this.view_profile_panel_2.Size = new System.Drawing.Size(751, 464);
            this.view_profile_panel_2.TabIndex = 2;
            this.view_profile_panel_2.Paint += new System.Windows.Forms.PaintEventHandler(this.view_profile_panel_Paint);
            // 
            // update_user_panel_3
            // 
            this.update_user_panel_3.BackColor = System.Drawing.Color.Aquamarine;
            this.update_user_panel_3.Controls.Add(this.frien_resuestsss_panel_5);
            this.update_user_panel_3.Controls.Add(this.search_panel_4);
            this.update_user_panel_3.Location = new System.Drawing.Point(0, 0);
            this.update_user_panel_3.Name = "update_user_panel_3";
            this.update_user_panel_3.Size = new System.Drawing.Size(734, 464);
            this.update_user_panel_3.TabIndex = 7;
            this.update_user_panel_3.Paint += new System.Windows.Forms.PaintEventHandler(this.update_user_panel_3_Paint);
            // 
            // frien_resuestsss_panel_5
            // 
            this.frien_resuestsss_panel_5.BackColor = System.Drawing.Color.Brown;
            this.frien_resuestsss_panel_5.Controls.Add(this.map_panel_6);
            this.frien_resuestsss_panel_5.Controls.Add(this.send_reuest_btn);
            this.frien_resuestsss_panel_5.Controls.Add(this.ADD_FRIEND_SEARCH_BTN);
            this.frien_resuestsss_panel_5.Controls.Add(this.add_friend_back_btn);
            this.frien_resuestsss_panel_5.Controls.Add(this.dataGridView1);
            this.frien_resuestsss_panel_5.Controls.Add(this.label9);
            this.frien_resuestsss_panel_5.Controls.Add(this.add_friend_tbox);
            this.frien_resuestsss_panel_5.Location = new System.Drawing.Point(5, -3);
            this.frien_resuestsss_panel_5.Name = "frien_resuestsss_panel_5";
            this.frien_resuestsss_panel_5.Size = new System.Drawing.Size(671, 467);
            this.frien_resuestsss_panel_5.TabIndex = 2;
            this.frien_resuestsss_panel_5.Paint += new System.Windows.Forms.PaintEventHandler(this.add_friend_panel_Paint);
            // 
            // map_panel_6
            // 
            this.map_panel_6.BackColor = System.Drawing.Color.BurlyWood;
            this.map_panel_6.Controls.Add(this.guna2find);
            this.map_panel_6.Controls.Add(this.webBrowser1);
            this.map_panel_6.Controls.Add(this.guna2Destination);
            this.map_panel_6.Controls.Add(this.Destination);
            this.map_panel_6.Controls.Add(this.guna2Location);
            this.map_panel_6.Controls.Add(this.guna2HtmlLabel1);
            this.map_panel_6.Location = new System.Drawing.Point(4, 7);
            this.map_panel_6.Name = "map_panel_6";
            this.map_panel_6.Size = new System.Drawing.Size(433, 479);
            this.map_panel_6.TabIndex = 6;
            this.map_panel_6.Paint += new System.Windows.Forms.PaintEventHandler(this.map_panel_6_Paint);
            // 
            // guna2find
            // 
            this.guna2find.DisabledState.BorderColor = System.Drawing.Color.DarkGray;
            this.guna2find.DisabledState.CustomBorderColor = System.Drawing.Color.DarkGray;
            this.guna2find.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(169)))), ((int)(((byte)(169)))), ((int)(((byte)(169)))));
            this.guna2find.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(141)))), ((int)(((byte)(141)))), ((int)(((byte)(141)))));
            this.guna2find.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.guna2find.ForeColor = System.Drawing.Color.White;
            this.guna2find.Location = new System.Drawing.Point(495, 25);
            this.guna2find.Name = "guna2find";
            this.guna2find.ShadowDecoration.Mode = Guna.UI2.WinForms.Enums.ShadowMode.Circle;
            this.guna2find.Size = new System.Drawing.Size(74, 47);
            this.guna2find.TabIndex = 5;
            this.guna2find.Text = "Search";
            this.guna2find.Click += new System.EventHandler(this.guna2find_Click);
            // 
            // webBrowser1
            // 
            this.webBrowser1.Location = new System.Drawing.Point(3, 111);
            this.webBrowser1.MinimumSize = new System.Drawing.Size(20, 20);
            this.webBrowser1.Name = "webBrowser1";
            this.webBrowser1.Size = new System.Drawing.Size(651, 355);
            this.webBrowser1.TabIndex = 4;
            this.webBrowser1.DocumentCompleted += new System.Windows.Forms.WebBrowserDocumentCompletedEventHandler(this.webBrowser1_DocumentCompleted);
            // 
            // guna2Destination
            // 
            this.guna2Destination.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.guna2Destination.DefaultText = "";
            this.guna2Destination.DisabledState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(208)))), ((int)(((byte)(208)))), ((int)(((byte)(208)))));
            this.guna2Destination.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(226)))), ((int)(((byte)(226)))), ((int)(((byte)(226)))));
            this.guna2Destination.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.guna2Destination.DisabledState.PlaceholderForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.guna2Destination.FocusedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.guna2Destination.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.guna2Destination.HoverState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.guna2Destination.Location = new System.Drawing.Point(327, 30);
            this.guna2Destination.Name = "guna2Destination";
            this.guna2Destination.PasswordChar = '\0';
            this.guna2Destination.PlaceholderText = "";
            this.guna2Destination.SelectedText = "";
            this.guna2Destination.Size = new System.Drawing.Size(159, 36);
            this.guna2Destination.TabIndex = 3;
            // 
            // Destination
            // 
            this.Destination.BackColor = System.Drawing.Color.Transparent;
            this.Destination.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Destination.Location = new System.Drawing.Point(232, 35);
            this.Destination.Name = "Destination";
            this.Destination.Size = new System.Drawing.Size(84, 22);
            this.Destination.TabIndex = 2;
            this.Destination.Text = "Destination";
            // 
            // guna2Location
            // 
            this.guna2Location.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.guna2Location.DefaultText = "";
            this.guna2Location.DisabledState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(208)))), ((int)(((byte)(208)))), ((int)(((byte)(208)))));
            this.guna2Location.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(226)))), ((int)(((byte)(226)))), ((int)(((byte)(226)))));
            this.guna2Location.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.guna2Location.DisabledState.PlaceholderForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.guna2Location.FocusedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.guna2Location.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.guna2Location.HoverState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.guna2Location.Location = new System.Drawing.Point(75, 31);
            this.guna2Location.Name = "guna2Location";
            this.guna2Location.PasswordChar = '\0';
            this.guna2Location.PlaceholderText = "";
            this.guna2Location.SelectedText = "";
            this.guna2Location.Size = new System.Drawing.Size(144, 32);
            this.guna2Location.TabIndex = 1;
            // 
            // guna2HtmlLabel1
            // 
            this.guna2HtmlLabel1.BackColor = System.Drawing.Color.Transparent;
            this.guna2HtmlLabel1.Location = new System.Drawing.Point(8, 37);
            this.guna2HtmlLabel1.Name = "guna2HtmlLabel1";
            this.guna2HtmlLabel1.Size = new System.Drawing.Size(63, 15);
            this.guna2HtmlLabel1.TabIndex = 0;
            this.guna2HtmlLabel1.Text = "your location";
            // 
            // send_reuest_btn
            // 
            this.send_reuest_btn.Location = new System.Drawing.Point(391, 60);
            this.send_reuest_btn.Name = "send_reuest_btn";
            this.send_reuest_btn.Size = new System.Drawing.Size(103, 23);
            this.send_reuest_btn.TabIndex = 5;
            this.send_reuest_btn.Text = "send request";
            this.send_reuest_btn.UseVisualStyleBackColor = true;
            this.send_reuest_btn.Click += new System.EventHandler(this.send_reuest_btn_Click);
            // 
            // ADD_FRIEND_SEARCH_BTN
            // 
            this.ADD_FRIEND_SEARCH_BTN.Location = new System.Drawing.Point(290, 56);
            this.ADD_FRIEND_SEARCH_BTN.Name = "ADD_FRIEND_SEARCH_BTN";
            this.ADD_FRIEND_SEARCH_BTN.Size = new System.Drawing.Size(75, 23);
            this.ADD_FRIEND_SEARCH_BTN.TabIndex = 4;
            this.ADD_FRIEND_SEARCH_BTN.Text = "SEARCH";
            this.ADD_FRIEND_SEARCH_BTN.UseVisualStyleBackColor = true;
            this.ADD_FRIEND_SEARCH_BTN.Click += new System.EventHandler(this.ADD_FRIEND_SEARCH_BTN_Click);
            // 
            // add_friend_back_btn
            // 
            this.add_friend_back_btn.Location = new System.Drawing.Point(230, 267);
            this.add_friend_back_btn.Name = "add_friend_back_btn";
            this.add_friend_back_btn.Size = new System.Drawing.Size(75, 23);
            this.add_friend_back_btn.TabIndex = 3;
            this.add_friend_back_btn.Text = "BACK";
            this.add_friend_back_btn.UseVisualStyleBackColor = true;
            this.add_friend_back_btn.Click += new System.EventHandler(this.add_friend_back_btn_Click);
            // 
            // dataGridView1
            // 
            this.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView1.Location = new System.Drawing.Point(3, 100);
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.Size = new System.Drawing.Size(579, 120);
            this.dataGridView1.TabIndex = 2;
            this.dataGridView1.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dataGridView1_CellContentClick);
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(30, 58);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(79, 13);
            this.label9.TabIndex = 1;
            this.label9.Text = "search friend id";
            // 
            // add_friend_tbox
            // 
            this.add_friend_tbox.Location = new System.Drawing.Point(168, 56);
            this.add_friend_tbox.Name = "add_friend_tbox";
            this.add_friend_tbox.Size = new System.Drawing.Size(100, 20);
            this.add_friend_tbox.TabIndex = 0;
            // 
            // search_panel_4
            // 
            this.search_panel_4.BackColor = System.Drawing.Color.BlueViolet;
            this.search_panel_4.Controls.Add(this.insode_search_tb_layout);
            this.search_panel_4.Location = new System.Drawing.Point(1, 3);
            this.search_panel_4.Name = "search_panel_4";
            this.search_panel_4.Size = new System.Drawing.Size(723, 461);
            this.search_panel_4.TabIndex = 1;
            this.search_panel_4.Paint += new System.Windows.Forms.PaintEventHandler(this.search_panel_4_Paint);
            // 
            // insode_search_tb_layout
            // 
            this.insode_search_tb_layout.ColumnCount = 2;
            this.insode_search_tb_layout.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 75.80645F));
            this.insode_search_tb_layout.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 24.19355F));
            this.insode_search_tb_layout.Controls.Add(this.tableLayoutPanel2, 1, 0);
            this.insode_search_tb_layout.Controls.Add(this.dataGV, 0, 0);
            this.insode_search_tb_layout.Controls.Add(this.panel6, 0, 1);
            this.insode_search_tb_layout.Location = new System.Drawing.Point(0, 0);
            this.insode_search_tb_layout.Name = "insode_search_tb_layout";
            this.insode_search_tb_layout.RowCount = 2;
            this.insode_search_tb_layout.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 85.22727F));
            this.insode_search_tb_layout.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 14.77273F));
            this.insode_search_tb_layout.Size = new System.Drawing.Size(528, 349);
            this.insode_search_tb_layout.TabIndex = 0;
            // 
            // tableLayoutPanel2
            // 
            this.tableLayoutPanel2.ColumnCount = 1;
            this.tableLayoutPanel2.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel2.Controls.Add(this.id_Box, 0, 0);
            this.tableLayoutPanel2.Controls.Add(this.searchButton, 0, 1);
            this.tableLayoutPanel2.Location = new System.Drawing.Point(403, 3);
            this.tableLayoutPanel2.Name = "tableLayoutPanel2";
            this.tableLayoutPanel2.RowCount = 2;
            this.tableLayoutPanel2.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel2.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel2.Size = new System.Drawing.Size(122, 291);
            this.tableLayoutPanel2.TabIndex = 0;
            // 
            // id_Box
            // 
            this.id_Box.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Left | System.Windows.Forms.AnchorStyles.Right)));
            this.id_Box.Location = new System.Drawing.Point(3, 62);
            this.id_Box.Name = "id_Box";
            this.id_Box.Size = new System.Drawing.Size(116, 20);
            this.id_Box.TabIndex = 0;
            // 
            // searchButton
            // 
            this.searchButton.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Left | System.Windows.Forms.AnchorStyles.Right)));
            this.searchButton.BackColor = System.Drawing.SystemColors.GradientActiveCaption;
            this.searchButton.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.searchButton.Location = new System.Drawing.Point(3, 197);
            this.searchButton.Name = "searchButton";
            this.searchButton.Size = new System.Drawing.Size(116, 42);
            this.searchButton.TabIndex = 1;
            this.searchButton.Text = "Search";
            this.searchButton.UseVisualStyleBackColor = false;
            this.searchButton.Click += new System.EventHandler(this.searchButton_Click);
            // 
            // dataGV
            // 
            this.dataGV.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGV.Dock = System.Windows.Forms.DockStyle.Fill;
            this.dataGV.Location = new System.Drawing.Point(3, 3);
            this.dataGV.Name = "dataGV";
            this.dataGV.Size = new System.Drawing.Size(394, 291);
            this.dataGV.TabIndex = 1;
            this.dataGV.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dataGV_CellContentClick);
            // 
            // panel6
            // 
            this.panel6.Controls.Add(this.button2);
            this.panel6.Location = new System.Drawing.Point(3, 300);
            this.panel6.Name = "panel6";
            this.panel6.Size = new System.Drawing.Size(394, 46);
            this.panel6.TabIndex = 2;
            // 
            // button2
            // 
            this.button2.Location = new System.Drawing.Point(146, 3);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(75, 37);
            this.button2.TabIndex = 0;
            this.button2.Text = "back";
            this.button2.UseVisualStyleBackColor = true;
            this.button2.Click += new System.EventHandler(this.button2_Click);
            // 
            // pro_name_txtbox
            // 
            this.pro_name_txtbox.Location = new System.Drawing.Point(321, 36);
            this.pro_name_txtbox.Multiline = true;
            this.pro_name_txtbox.Name = "pro_name_txtbox";
            this.pro_name_txtbox.Size = new System.Drawing.Size(210, 36);
            this.pro_name_txtbox.TabIndex = 1;
            // 
            // pro_phone_txtbox
            // 
            this.pro_phone_txtbox.Location = new System.Drawing.Point(321, 105);
            this.pro_phone_txtbox.Multiline = true;
            this.pro_phone_txtbox.Name = "pro_phone_txtbox";
            this.pro_phone_txtbox.Size = new System.Drawing.Size(210, 32);
            this.pro_phone_txtbox.TabIndex = 4;
            // 
            // pro_locat_txtbox
            // 
            this.pro_locat_txtbox.Location = new System.Drawing.Point(321, 170);
            this.pro_locat_txtbox.Multiline = true;
            this.pro_locat_txtbox.Name = "pro_locat_txtbox";
            this.pro_locat_txtbox.Size = new System.Drawing.Size(210, 37);
            this.pro_locat_txtbox.TabIndex = 5;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Microsoft Sans Serif", 21.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.Location = new System.Drawing.Point(78, 39);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(153, 33);
            this.label5.TabIndex = 0;
            this.label5.Text = "your name";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Microsoft Sans Serif", 24F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.Location = new System.Drawing.Point(91, 105);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(124, 37);
            this.label6.TabIndex = 2;
            this.label6.Text = "phone#";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Microsoft Sans Serif", 24F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.Location = new System.Drawing.Point(97, 170);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(128, 37);
            this.label7.TabIndex = 3;
            this.label7.Text = "location";
            // 
            // profile_back
            // 
            this.profile_back.Location = new System.Drawing.Point(190, 271);
            this.profile_back.Name = "profile_back";
            this.profile_back.Size = new System.Drawing.Size(118, 23);
            this.profile_back.TabIndex = 6;
            this.profile_back.Text = "BACK";
            this.profile_back.UseVisualStyleBackColor = true;
            this.profile_back.Click += new System.EventHandler(this.profile_back_Click);
            // 
            // panel5
            // 
            this.panel5.Location = new System.Drawing.Point(682, 224);
            this.panel5.Name = "panel5";
            this.panel5.Size = new System.Drawing.Size(113, 46);
            this.panel5.TabIndex = 8;
            // 
            // panel3
            // 
            this.panel3.BackColor = System.Drawing.Color.Transparent;
            this.panel3.Controls.Add(this.active_user_text);
            this.panel3.Controls.Add(this.label3);
            this.panel3.Location = new System.Drawing.Point(64, 24);
            this.panel3.Name = "panel3";
            this.panel3.Size = new System.Drawing.Size(200, 94);
            this.panel3.TabIndex = 0;
            // 
            // active_user_text
            // 
            this.active_user_text.Location = new System.Drawing.Point(69, 42);
            this.active_user_text.Multiline = true;
            this.active_user_text.Name = "active_user_text";
            this.active_user_text.Size = new System.Drawing.Size(64, 34);
            this.active_user_text.TabIndex = 1;
            this.active_user_text.Text = " ";
            this.active_user_text.TextChanged += new System.EventHandler(this.active_user_text_TextChanged);
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.ForeColor = System.Drawing.SystemColors.Info;
            this.label3.Location = new System.Drawing.Point(66, 16);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(67, 13);
            this.label3.TabIndex = 0;
            this.label3.Text = "Active Users";
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(256, 358);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(112, 27);
            this.button1.TabIndex = 3;
            this.button1.Text = "back";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // panel2
            // 
            this.panel2.BackColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.panel2.Controls.Add(this.msg_btn);
            this.panel2.Controls.Add(this.guna2GradientButton2);
            this.panel2.Controls.Add(this.guna2GradientButton1);
            this.panel2.Controls.Add(this.loc_map_btn);
            this.panel2.Controls.Add(this.search_btn);
            this.panel2.Controls.Add(this.friend_request_btn);
            this.panel2.Controls.Add(this.add_friend_btn);
            this.panel2.Controls.Add(this.view_profile);
            this.panel2.Controls.Add(this.dashboard_btn);
            this.panel2.Location = new System.Drawing.Point(3, 59);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(160, 437);
            this.panel2.TabIndex = 2;
            // 
            // msg_btn
            // 
            this.msg_btn.BackColor = System.Drawing.Color.Gainsboro;
            this.msg_btn.DisabledState.BorderColor = System.Drawing.Color.DarkGray;
            this.msg_btn.DisabledState.CustomBorderColor = System.Drawing.Color.DarkGray;
            this.msg_btn.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(169)))), ((int)(((byte)(169)))), ((int)(((byte)(169)))));
            this.msg_btn.DisabledState.FillColor2 = System.Drawing.Color.FromArgb(((int)(((byte)(169)))), ((int)(((byte)(169)))), ((int)(((byte)(169)))));
            this.msg_btn.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(141)))), ((int)(((byte)(141)))), ((int)(((byte)(141)))));
            this.msg_btn.FillColor = System.Drawing.Color.Transparent;
            this.msg_btn.FillColor2 = System.Drawing.Color.Transparent;
            this.msg_btn.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.msg_btn.ForeColor = System.Drawing.Color.Black;
            this.msg_btn.Location = new System.Drawing.Point(10, 253);
            this.msg_btn.Name = "msg_btn";
            this.msg_btn.Size = new System.Drawing.Size(143, 29);
            this.msg_btn.TabIndex = 9;
            this.msg_btn.Text = "Messaging";
            this.msg_btn.Click += new System.EventHandler(this.msg_btn_Click);
            // 
            // guna2GradientButton2
            // 
            this.guna2GradientButton2.BackColor = System.Drawing.Color.SeaGreen;
            this.guna2GradientButton2.DisabledState.BorderColor = System.Drawing.Color.DarkGray;
            this.guna2GradientButton2.DisabledState.CustomBorderColor = System.Drawing.Color.DarkGray;
            this.guna2GradientButton2.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(169)))), ((int)(((byte)(169)))), ((int)(((byte)(169)))));
            this.guna2GradientButton2.DisabledState.FillColor2 = System.Drawing.Color.FromArgb(((int)(((byte)(169)))), ((int)(((byte)(169)))), ((int)(((byte)(169)))));
            this.guna2GradientButton2.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(141)))), ((int)(((byte)(141)))), ((int)(((byte)(141)))));
            this.guna2GradientButton2.FillColor = System.Drawing.Color.Transparent;
            this.guna2GradientButton2.FillColor2 = System.Drawing.Color.Transparent;
            this.guna2GradientButton2.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.guna2GradientButton2.ForeColor = System.Drawing.Color.White;
            this.guna2GradientButton2.Location = new System.Drawing.Point(6, 393);
            this.guna2GradientButton2.Name = "guna2GradientButton2";
            this.guna2GradientButton2.Size = new System.Drawing.Size(148, 36);
            this.guna2GradientButton2.TabIndex = 8;
            this.guna2GradientButton2.Text = "LOG OUT";
            this.guna2GradientButton2.Click += new System.EventHandler(this.guna2GradientButton2_Click);
            // 
            // guna2GradientButton1
            // 
            this.guna2GradientButton1.BackColor = System.Drawing.Color.Gainsboro;
            this.guna2GradientButton1.DisabledState.BorderColor = System.Drawing.Color.DarkGray;
            this.guna2GradientButton1.DisabledState.CustomBorderColor = System.Drawing.Color.DarkGray;
            this.guna2GradientButton1.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(169)))), ((int)(((byte)(169)))), ((int)(((byte)(169)))));
            this.guna2GradientButton1.DisabledState.FillColor2 = System.Drawing.Color.FromArgb(((int)(((byte)(169)))), ((int)(((byte)(169)))), ((int)(((byte)(169)))));
            this.guna2GradientButton1.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(141)))), ((int)(((byte)(141)))), ((int)(((byte)(141)))));
            this.guna2GradientButton1.FillColor = System.Drawing.Color.Transparent;
            this.guna2GradientButton1.FillColor2 = System.Drawing.Color.Transparent;
            this.guna2GradientButton1.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.guna2GradientButton1.ForeColor = System.Drawing.Color.Black;
            this.guna2GradientButton1.Location = new System.Drawing.Point(10, 214);
            this.guna2GradientButton1.Name = "guna2GradientButton1";
            this.guna2GradientButton1.Size = new System.Drawing.Size(141, 24);
            this.guna2GradientButton1.TabIndex = 7;
            this.guna2GradientButton1.Text = "see friend";
            this.guna2GradientButton1.Click += new System.EventHandler(this.guna2GradientButton1_Click);
            // 
            // loc_map_btn
            // 
            this.loc_map_btn.BackColor = System.Drawing.Color.Gainsboro;
            this.loc_map_btn.Location = new System.Drawing.Point(10, 179);
            this.loc_map_btn.Name = "loc_map_btn";
            this.loc_map_btn.Size = new System.Drawing.Size(141, 23);
            this.loc_map_btn.TabIndex = 6;
            this.loc_map_btn.Text = "Loction on map";
            this.loc_map_btn.UseVisualStyleBackColor = false;
            this.loc_map_btn.Click += new System.EventHandler(this.loc_map_btn_Click);
            // 
            // search_btn
            // 
            this.search_btn.BackColor = System.Drawing.Color.Gainsboro;
            this.search_btn.Location = new System.Drawing.Point(8, 146);
            this.search_btn.Name = "search_btn";
            this.search_btn.Size = new System.Drawing.Size(144, 23);
            this.search_btn.TabIndex = 5;
            this.search_btn.Text = "Search Friend";
            this.search_btn.UseVisualStyleBackColor = false;
            this.search_btn.Click += new System.EventHandler(this.search_btn_Click);
            // 
            // friend_request_btn
            // 
            this.friend_request_btn.BackColor = System.Drawing.Color.Gainsboro;
            this.friend_request_btn.Location = new System.Drawing.Point(9, 111);
            this.friend_request_btn.Name = "friend_request_btn";
            this.friend_request_btn.Size = new System.Drawing.Size(144, 22);
            this.friend_request_btn.TabIndex = 4;
            this.friend_request_btn.Text = "Friend request";
            this.friend_request_btn.UseVisualStyleBackColor = false;
            this.friend_request_btn.Click += new System.EventHandler(this.friend_request_btn_Click);
            // 
            // add_friend_btn
            // 
            this.add_friend_btn.BackColor = System.Drawing.Color.Gainsboro;
            this.add_friend_btn.Location = new System.Drawing.Point(6, 79);
            this.add_friend_btn.Name = "add_friend_btn";
            this.add_friend_btn.Size = new System.Drawing.Size(148, 26);
            this.add_friend_btn.TabIndex = 3;
            this.add_friend_btn.Text = "Add  Friend";
            this.add_friend_btn.UseVisualStyleBackColor = false;
            this.add_friend_btn.Click += new System.EventHandler(this.add_friend_btn_Click);
            // 
            // view_profile
            // 
            this.view_profile.BackColor = System.Drawing.Color.Gainsboro;
            this.view_profile.Location = new System.Drawing.Point(6, 44);
            this.view_profile.Name = "view_profile";
            this.view_profile.Size = new System.Drawing.Size(151, 29);
            this.view_profile.TabIndex = 1;
            this.view_profile.Text = "view profile";
            this.view_profile.UseVisualStyleBackColor = false;
            this.view_profile.Click += new System.EventHandler(this.view_profile_Click);
            // 
            // dashboard_btn
            // 
            this.dashboard_btn.BackColor = System.Drawing.Color.Gainsboro;
            this.dashboard_btn.ForeColor = System.Drawing.SystemColors.ControlText;
            this.dashboard_btn.Location = new System.Drawing.Point(6, 12);
            this.dashboard_btn.Name = "dashboard_btn";
            this.dashboard_btn.Size = new System.Drawing.Size(151, 26);
            this.dashboard_btn.TabIndex = 0;
            this.dashboard_btn.Text = "Dashboard";
            this.dashboard_btn.UseVisualStyleBackColor = false;
            this.dashboard_btn.Click += new System.EventHandler(this.dashboard_btn_Click);
            // 
            // title_panel
            // 
            this.title_panel.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.title_panel.BackColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.title_panel.Controls.Add(this.label1);
            this.title_panel.Font = new System.Drawing.Font("Microsoft YaHei UI", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.title_panel.Location = new System.Drawing.Point(173, 3);
            this.title_panel.Name = "title_panel";
            this.title_panel.Size = new System.Drawing.Size(862, 66);
            this.title_panel.TabIndex = 0;
            this.title_panel.Paint += new System.Windows.Forms.PaintEventHandler(this.title_panel_Paint);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Algerian", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.SystemColors.Info;
            this.label1.Location = new System.Drawing.Point(334, 19);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(120, 26);
            this.label1.TabIndex = 0;
            this.label1.Text = "We’frnds";
            // 
            // Admin_login
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1070, 552);
            this.Controls.Add(this.admin_panel);
            this.Name = "Admin_login";
            this.Text = "Admin_login";
            this.Load += new System.EventHandler(this.Admin_login_Load);
            this.admin_panel.ResumeLayout(false);
            this.dash_board_panel_1.ResumeLayout(false);
            this.view_profile_panel_2.ResumeLayout(false);
            this.view_profile_panel_2.PerformLayout();
            this.update_user_panel_3.ResumeLayout(false);
            this.frien_resuestsss_panel_5.ResumeLayout(false);
            this.frien_resuestsss_panel_5.PerformLayout();
            this.map_panel_6.ResumeLayout(false);
            this.map_panel_6.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
            this.search_panel_4.ResumeLayout(false);
            this.insode_search_tb_layout.ResumeLayout(false);
            this.tableLayoutPanel2.ResumeLayout(false);
            this.tableLayoutPanel2.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGV)).EndInit();
            this.panel6.ResumeLayout(false);
            this.panel3.ResumeLayout(false);
            this.panel3.PerformLayout();
            this.panel2.ResumeLayout(false);
            this.title_panel.ResumeLayout(false);
            this.title_panel.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel admin_panel;
        private System.Windows.Forms.Panel title_panel;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.Panel dash_board_panel_1;
        private System.Windows.Forms.Panel panel3;
        private System.Windows.Forms.Button view_profile;
        private System.Windows.Forms.Button dashboard_btn;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Panel view_profile_panel_2;
        private System.Windows.Forms.TextBox active_user_text;
        private System.Windows.Forms.Button profile_back;
        private System.Windows.Forms.TextBox pro_locat_txtbox;
        private System.Windows.Forms.TextBox pro_phone_txtbox;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.TextBox pro_name_txtbox;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Panel update_user_panel_3;
        private System.Windows.Forms.Button friend_request_btn;
        private System.Windows.Forms.Button add_friend_btn;
        private System.Windows.Forms.Panel search_panel_4;
        private System.Windows.Forms.TableLayoutPanel insode_search_tb_layout;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel2;
        private System.Windows.Forms.TextBox id_Box;
        private System.Windows.Forms.Button searchButton;
        private System.Windows.Forms.DataGridView dataGV;
        private System.Windows.Forms.Button search_btn;
        private System.Windows.Forms.Panel panel5;
        private System.Windows.Forms.Panel frien_resuestsss_panel_5;
        private System.Windows.Forms.TextBox add_friend_tbox;
        private System.Windows.Forms.Button add_friend_back_btn;
        private System.Windows.Forms.DataGridView dataGridView1;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Button ADD_FRIEND_SEARCH_BTN;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Panel panel6;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.Button send_reuest_btn;
        private System.Windows.Forms.Button loc_map_btn;
        private System.Windows.Forms.Panel map_panel_6;
        private Guna.UI2.WinForms.Guna2HtmlLabel guna2HtmlLabel1;
        private System.Windows.Forms.WebBrowser webBrowser1;
        private Guna.UI2.WinForms.Guna2TextBox guna2Destination;
        private Guna.UI2.WinForms.Guna2HtmlLabel Destination;
        private Guna.UI2.WinForms.Guna2TextBox guna2Location;
        private Guna.UI2.WinForms.Guna2CircleButton guna2find;
        private Guna.UI2.WinForms.Guna2ImageButton guna2ImageButton1;
        private System.Windows.Forms.ImageList imageList1;
        private Guna.UI2.WinForms.Guna2GradientButton guna2GradientButton1;
        private Guna.UI2.WinForms.Guna2GradientButton guna2GradientButton2;
        private Guna.UI2.WinForms.Guna2GradientButton msg_btn;
    }
}