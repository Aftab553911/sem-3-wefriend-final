﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using sem3Final.BL;
using sem3Final.DL;

using System.Windows.Forms;

namespace sem3Final
{
    public partial class Admin_login : Form
    {
        int c_box=0;
      user_bl new_user;
        user_bl send_friends_request;
        List<user_bl> local_id_list = new List<user_bl>();
         public  Admin_login(user_bl new_user)
        {
            InitializeComponent();
            this.new_user = new_user;
            webBrowser1.ScriptErrorsSuppressed = true;

        }


        private void title_panel_Paint(object sender, PaintEventArgs e)
        {

        }

        private void panel4_Paint(object sender, PaintEventArgs e)
        {


        }
        private void view_profile_Click(object sender, EventArgs e)
        {
            hide_all_panels();
         
            dash_board_panel_1.Show();
            view_profile_panel_2.BringToFront();
            view_profile_panel_2.Show();
    

        }

        private void dashboard_btn_Click(object sender, EventArgs e)
        {
            //dash_board_panel.Show();
            //view_profile_panel.Hide();
            hide_all_panels();
             dash_board_panel_1.Show();
            //view_profile_panel.Show();
        }

        private void active_user_text_TextChanged(object sender, EventArgs e)
        {

        }

        private void dash_board_panel_Paint(object sender, PaintEventArgs e)
        {
            active_user_text.Text=" "+ user_dl.users_list.Count;
        }

        private void view_profile_panel_Paint(object sender, PaintEventArgs e)
        {
            pro_name_txtbox.Text = new_user.Name;
            pro_phone_txtbox.Text = new_user.Phone_number;
            pro_locat_txtbox.Text = new_user.Location;
           // MessageBox.Show("i am inside the view profile panel");

        }

        private void profile_back_Click(object sender, EventArgs e)
        {
            hide_all_panels();
            dash_board_panel_1.Show();

        }

        private void Admin_login_Load(object sender, EventArgs e)
        {
          
            
            hide_all_panels();
            dash_board_panel_1.Show();
            //view_profile_panel.Hide();
        }
        private void hide_all_panels()
        {
            update_user_panel_3.Hide();
            view_profile_panel_2.Hide();
            dash_board_panel_1.Hide();
           // MessageBox.Show("aftab ali    cs 166");
        }

        private void update_user_Click(object sender, EventArgs e)
        {
            hide_all_panels();
            update_user_panel_3.Show();
 }

        private void add_friend_btn_Click(object sender, EventArgs e)
        {
            add_friend_panel f = new add_friend_panel(new_user);
            f.Show();
            this.Close();
           
        }

        private void searchButton_Click(object sender, EventArgs e)
        {
            //local_id_list.Clear();

            string name = id_Box.Text;
            MessageBox.Show(user_dl.users_list.Count.ToString());
            foreach(user_bl user in user_dl.users_list)
            {
                if(name == user.Name)
                {

                    local_id_list.Add(user);
                }
            }
            dataGV.DataSource = local_id_list;

        }

        private void search_panel_4_Paint(object sender, PaintEventArgs e)
        {

        }

        private void update_user_panel_3_Paint(object sender, PaintEventArgs e)
        {

        }

        private void search_btn_Click(object sender, EventArgs e)
        {
            dash_board_panel_1.Visible = true;
            view_profile_panel_2.Visible = true;
            update_user_panel_3.Visible = true;
            search_panel_4.Visible = true;
            frien_resuestsss_panel_5.Visible = false;
            map_panel_6.Visible = false;

        }

        private void add_friend_panel_Paint(object sender, PaintEventArgs e)
        {
        }
          
        private void send_reuest_btn_Click(object sender, EventArgs e)
        {

            if (send_friends_request != null)
            {
                if (!user_dl.send_request_Dict.ContainsKey(send_friends_request))
                {
                        user_dl.send_request_Dict.Add(send_friends_request, new List<user_bl>());                        
                }
                if (!user_dl.send_request_Dict.ContainsKey(new_user))
                {
                    user_dl.send_request_Dict.Add(new_user, new List<user_bl>());
                }
                user_dl.send_request_Dict[send_friends_request].Add(new_user);
                user_dl.s_r_friend_request_write_file(new_user, send_friends_request);
                local_id_list.Clear();
                dataGridView1.DataSource = null;

            }
            else
            {
                MessageBox.Show("please select friend you wanted to send request");
            }

        }
        private void ADD_FRIEND_SEARCH_BTN_Click(object sender, EventArgs e)
        {

            string id =add_friend_tbox.Text;
            foreach (user_bl user in user_dl.users_list)
            {
                if (id == user.Id)
                {
                    local_id_list.Add(user);
                    send_friends_request = user;
                    dataGridView1.DataSource = local_id_list;  
                    break;
                  }
            }
        }

        private void add_friend_back_btn_Click(object sender, EventArgs e)
        {
            hide_all_panels();
            dash_board_panel_1.Show();
        }

        private void friend_request_btn_Click(object sender, EventArgs e)
        {
            dash_board_panel_1.Visible = true;
            view_profile_panel_2.Visible = true;
            update_user_panel_3.Visible = true;
            search_panel_4.Visible = true;
            frien_resuestsss_panel_5.Visible = true;
          //  search_panel_4.Visible = false;
            map_panel_6.Visible = false;


        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void dataGV_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            hide_all_panels();
            sign_in_up n =new sign_in_up();
            n.Show();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            hide_all_panels();
            dash_board_panel_1.Show();
        }

        private void webBrowser1_DocumentCompleted(object sender, WebBrowserDocumentCompletedEventArgs e)
        {

        }

        private void guna2find_Click(object sender, EventArgs e)
        {
            string current_location = guna2Location.Text;
            string distination = guna2Destination.Text;
            StringBuilder queryAddress = new StringBuilder();
          //this.map_panel_6=.MaximumSize;
            queryAddress.Append("https://www.google.com/maps/dir/");
            if (current_location != string.Empty)
            {
                queryAddress.Append(current_location +"/");
            }

            if (distination != string.Empty)
            {
                queryAddress.Append(distination + "/");
            }
            webBrowser1.Navigate(queryAddress.ToString());

        }

        private void loc_map_btn_Click(object sender, EventArgs e)
        {
            hide_all_panels();
            dash_board_panel_1.Visible = true;
            view_profile_panel_2.Visible = true;
            update_user_panel_3.Visible = true;
            search_panel_4.Visible = true;
            frien_resuestsss_panel_5.Visible = true;
            map_panel_6.Visible = true;

        }

        private void map_panel_6_Paint(object sender, PaintEventArgs e)
        {

        }

        private void guna2ImageButton1_Click(object sender, EventArgs e)
        {
           // PictureBox pic = new PictureBox();
           // Panel panel = new Panel();
           // this.Controls.Add(panel);
           //// pic.Image= sem3Final.re
        }

        private void fnd_btn_Click(object sender, EventArgs e)
        {
            this.Hide();
            SeeMyFriend form = new SeeMyFriend(send_friends_request);
            form.Show();
        }

        private void label8_Click(object sender, EventArgs e)
        {

        }

        private void guna2GradientButton1_Click(object sender, EventArgs e)
        {
            this.Hide();
            SeeMyFriend f = new SeeMyFriend(new_user);
            f.Show();

        }

        private void guna2GradientButton2_Click(object sender, EventArgs e)
        {
            sign_in_up f = new sign_in_up();
            f.Show();
            this.Close();
        }

        private void msg_btn_Click(object sender, EventArgs e)
        {
            Message f = new Message(new_user);
            f.Show();
            this.Close();


        }

    }
}
