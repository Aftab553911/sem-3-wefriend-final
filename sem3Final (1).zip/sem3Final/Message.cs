﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using sem3Final.BL;
using sem3Final.DL;

namespace sem3Final
{
    public partial class Message : Form
    {
        user_bl new_user;
           public Message(user_bl new_user)
        {
            InitializeComponent();
            this.new_user = new_user;
        }

        private void Message_Load(object sender, EventArgs e)
        {

        }

        private void guna2TextBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
        }
    }
}
