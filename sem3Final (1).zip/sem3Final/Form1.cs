﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using sem3Final.BL;
using sem3Final.DL;

using System.Windows.Forms;

namespace sem3Final
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void login_btn_Click(object sender, EventArgs e)
        {
            //bool flag = false;
            string user_name, password, user_type;
            user_name = username_input.Text;
            password = password_input.Text;
            user_type = admin_rb.Text;
            if (username_input.Text == "" || password_input.Text == "" || admin_rb.Text == "")
            {

                MessageBox.Show("Please! Fill All Credentials  :)");
            }
            else
            {


                user_bl new_user = new user_bl();
                new_user = user_dl.check_user(user_name, password, user_type);
                if (new_user == null)
                {
                    MessageBox.Show("WE do not have such User :) ");
                }
                else
                {
                    if (new_user.User_type == "admin")
                    {
                        this.Hide();
                        Admin_login foam = new Admin_login(new_user);
                        foam.Show();
                    }
                    else
                    {
                        this.Hide();
                        Admin_login foam = new Admin_login(new_user);
                        foam.Show();
                    }
                }
            }

        }

        private void panel1_Paint(object sender, PaintEventArgs e)
        {

        }

        private void password_input_TextChanged(object sender, EventArgs e)
        {

        }
    }
}
