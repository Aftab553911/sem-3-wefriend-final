﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using sem3Final.DL;
using sem3Final.BL;
using System.Windows.Forms;

namespace sem3Final
{
    public partial class sign_in_up : Form
    {
        public sign_in_up()
        {
            InitializeComponent();
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void SignUp_btn_Click(object sender, EventArgs e)
        {
            this.Hide();
            sign_up_new_user foam = new sign_up_new_user();
            foam.Show();
        }

        private void signIn_btn_Click(object sender, EventArgs e)
        {
             this.Hide();
            Form1 foam = new Form1();
            foam.Show();
        }

        private void panel1_Paint(object sender, PaintEventArgs e)
        {

        }

        private void sign_in_up_Load(object sender, EventArgs e)
        {
            user_dl.load_users();
            user_dl.s_r_friend_request_load_file();
            user_dl.main_graph_load_file();
        }

        private void label2_Click(object sender, EventArgs e)
        {

        }
    }
}
