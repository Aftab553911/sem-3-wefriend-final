﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using sem3Final.BL;
using sem3Final.DL;

namespace sem3Final
{
    public partial class add_friend_panel : Form
    {
        user_bl new_user;
        public add_friend_panel(user_bl new_user)
        {
            InitializeComponent();
            this.new_user = new_user;

        }

        private void guna2DataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void guna2Panel1_Paint(object sender, PaintEventArgs e)
        {
            foreach(KeyValuePair<user_bl,List<user_bl>> user in user_dl.send_request_Dict)
            {
                if(user.Key.Id ==  new_user.Id)
                {
                    acccccep_gv.DataSource = user.Value;
                   
                }
            }
        }

        private void acccccep_gv_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void add_btn_Click(object sender, EventArgs e)
        {
            string id = text_box_add.Text;
            foreach(user_bl user in user_dl.users_list)
            {
                if(id == user.Id)
                {
                    if (!user_dl.main_dict.ContainsKey(user))
                    {
                        user_dl.main_dict.Add(user, new List<user_bl>());
                    }
                    if(!user_dl.main_dict.ContainsKey(new_user))
                    {
                        user_dl.main_dict.Add(new_user, new List<user_bl>());
                    }
                    user_dl.main_dict[new_user].Add(user);
                    user_dl.main_dict[user].Add(new_user);
                    user_dl.main_graph_write_data(new_user, user);
                    user_dl.s_r_friend_request_delete(new_user, user);
                    user_dl.re_write_request("send_receive_friends_data.txt");
                    MessageBox.Show(user_dl.counter);
                    MessageBox.Show(" Request Accept Successfully ");
                    
                    break;
                }
            }

        }

        private void add_friend_panel_Load(object sender, EventArgs e)
        {

        }

        private void guna2GradientButton1_Click(object sender, EventArgs e)
        {
            Admin_login f = new Admin_login(new_user);
            f.Show();
            this.Close();
        }
    }
}
