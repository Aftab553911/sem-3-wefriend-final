﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using sem3Final.DL;

namespace sem3Final.BL
{
  public  class user_bl
    {
        private string user_type;
        private string name;
        private string id;
        private string phone_number;
        private string location;
        private string gender;
       

        public string Name { get => name; set => name = value; }
        public string Id { get => id; set => id = value; }
        public string Phone_number { get => phone_number; set => phone_number = value; }
        public string Location { get => location; set => location = value; }
        public string Gender { get => gender; set => gender = value; }
        public string User_type { get => user_type; set => user_type = value; }

        public user_bl()
        {

}  
        public user_bl(string name,string id,string phone_number, string location,string gender,string user_type)
        {
            this.user_type = user_type;
            this.name = name;
            this.id = id;
            this.gender = gender;
            this.location = location;
            this.phone_number = phone_number;
        }
        //public user_bl(string key ,string name, string id, string phone_number, string location, string gender, string user_type)
        //{
        //    this.user_type = user_type;
          
        //    this.name = name;
        //    this.id = id;
        //    this.gender = gender;
        //    this.location = location;
        //    this.phone_number = phone_number;
        //}


    }
    
}
