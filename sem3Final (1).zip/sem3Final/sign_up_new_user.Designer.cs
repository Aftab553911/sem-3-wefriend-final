﻿
namespace sem3Final
{
    partial class sign_up_new_user
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.panel1 = new System.Windows.Forms.Panel();
            this.guna2TextBox1 = new Guna.UI2.WinForms.Guna2TextBox();
            this.guna2PictureBox1 = new Guna.UI2.WinForms.Guna2PictureBox();
            this.user_type_lbl = new System.Windows.Forms.Label();
            this.user_rad_btn = new System.Windows.Forms.RadioButton();
            this.admin_rad_btn = new System.Windows.Forms.RadioButton();
            this.next_btn = new System.Windows.Forms.Button();
            this.back_btn = new System.Windows.Forms.Button();
            this.location_combo = new System.Windows.Forms.Label();
            this.phone_label = new System.Windows.Forms.Label();
            this.gender_label = new System.Windows.Forms.Label();
            this.ID_lbl = new System.Windows.Forms.Label();
            this.name_lbl = new System.Windows.Forms.Label();
            this.comboBox1 = new System.Windows.Forms.ComboBox();
            this.phone_textbox = new System.Windows.Forms.TextBox();
            this.female_rb = new System.Windows.Forms.RadioButton();
            this.male_rb = new System.Windows.Forms.RadioButton();
            this.id_textbox = new System.Windows.Forms.TextBox();
            this.name_textbox = new System.Windows.Forms.TextBox();
            this.panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.guna2PictureBox1)).BeginInit();
            this.SuspendLayout();
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.panel1.BackgroundImage = global::sem3Final.Properties.Resources.download__2_;
            this.panel1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.panel1.Controls.Add(this.guna2TextBox1);
            this.panel1.Controls.Add(this.guna2PictureBox1);
            this.panel1.Controls.Add(this.user_type_lbl);
            this.panel1.Controls.Add(this.user_rad_btn);
            this.panel1.Controls.Add(this.admin_rad_btn);
            this.panel1.Controls.Add(this.next_btn);
            this.panel1.Controls.Add(this.back_btn);
            this.panel1.Controls.Add(this.location_combo);
            this.panel1.Controls.Add(this.phone_label);
            this.panel1.Controls.Add(this.gender_label);
            this.panel1.Controls.Add(this.ID_lbl);
            this.panel1.Controls.Add(this.name_lbl);
            this.panel1.Controls.Add(this.comboBox1);
            this.panel1.Controls.Add(this.phone_textbox);
            this.panel1.Controls.Add(this.female_rb);
            this.panel1.Controls.Add(this.male_rb);
            this.panel1.Controls.Add(this.id_textbox);
            this.panel1.Controls.Add(this.name_textbox);
            this.panel1.Location = new System.Drawing.Point(-1, 1);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(495, 529);
            this.panel1.TabIndex = 0;
            this.panel1.Paint += new System.Windows.Forms.PaintEventHandler(this.panel1_Paint);
            // 
            // guna2TextBox1
            // 
            this.guna2TextBox1.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.guna2TextBox1.BackColor = System.Drawing.Color.Transparent;
            this.guna2TextBox1.BorderColor = System.Drawing.Color.Transparent;
            this.guna2TextBox1.BorderRadius = 20;
            this.guna2TextBox1.BorderStyle = System.Drawing.Drawing2D.DashStyle.DashDot;
            this.guna2TextBox1.BorderThickness = 3;
            this.guna2TextBox1.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.guna2TextBox1.DefaultText = "Lets Sign Up !!!\r\n";
            this.guna2TextBox1.DisabledState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(208)))), ((int)(((byte)(208)))), ((int)(((byte)(208)))));
            this.guna2TextBox1.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(226)))), ((int)(((byte)(226)))), ((int)(((byte)(226)))));
            this.guna2TextBox1.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.guna2TextBox1.DisabledState.PlaceholderForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.guna2TextBox1.FillColor = System.Drawing.Color.Gainsboro;
            this.guna2TextBox1.FocusedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.guna2TextBox1.Font = new System.Drawing.Font("Gabriola", 15.75F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))));
            this.guna2TextBox1.ForeColor = System.Drawing.Color.Transparent;
            this.guna2TextBox1.HoverState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.guna2TextBox1.Location = new System.Drawing.Point(231, 71);
            this.guna2TextBox1.Margin = new System.Windows.Forms.Padding(4, 7, 4, 7);
            this.guna2TextBox1.Name = "guna2TextBox1";
            this.guna2TextBox1.PasswordChar = '\0';
            this.guna2TextBox1.PlaceholderText = "";
            this.guna2TextBox1.SelectedText = "";
            this.guna2TextBox1.Size = new System.Drawing.Size(251, 67);
            this.guna2TextBox1.TabIndex = 17;
            // 
            // guna2PictureBox1
            // 
            this.guna2PictureBox1.BackColor = System.Drawing.Color.Transparent;
            this.guna2PictureBox1.Image = global::sem3Final.Properties.Resources.images_removebg_preview;
            this.guna2PictureBox1.ImageRotate = 0F;
            this.guna2PictureBox1.Location = new System.Drawing.Point(0, 0);
            this.guna2PictureBox1.Name = "guna2PictureBox1";
            this.guna2PictureBox1.Size = new System.Drawing.Size(240, 200);
            this.guna2PictureBox1.TabIndex = 16;
            this.guna2PictureBox1.TabStop = false;
            // 
            // user_type_lbl
            // 
            this.user_type_lbl.AutoSize = true;
            this.user_type_lbl.BackColor = System.Drawing.Color.Transparent;
            this.user_type_lbl.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.user_type_lbl.Location = new System.Drawing.Point(44, 416);
            this.user_type_lbl.Name = "user_type_lbl";
            this.user_type_lbl.Size = new System.Drawing.Size(107, 25);
            this.user_type_lbl.TabIndex = 15;
            this.user_type_lbl.Text = "user_type";
            // 
            // user_rad_btn
            // 
            this.user_rad_btn.AutoSize = true;
            this.user_rad_btn.BackColor = System.Drawing.Color.Transparent;
            this.user_rad_btn.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.user_rad_btn.ForeColor = System.Drawing.SystemColors.ControlText;
            this.user_rad_btn.Location = new System.Drawing.Point(267, 423);
            this.user_rad_btn.Name = "user_rad_btn";
            this.user_rad_btn.Size = new System.Drawing.Size(49, 17);
            this.user_rad_btn.TabIndex = 14;
            this.user_rad_btn.TabStop = true;
            this.user_rad_btn.Text = "user";
            this.user_rad_btn.UseVisualStyleBackColor = false;
            // 
            // admin_rad_btn
            // 
            this.admin_rad_btn.AutoSize = true;
            this.admin_rad_btn.BackColor = System.Drawing.Color.Transparent;
            this.admin_rad_btn.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.admin_rad_btn.Location = new System.Drawing.Point(165, 423);
            this.admin_rad_btn.Name = "admin_rad_btn";
            this.admin_rad_btn.Size = new System.Drawing.Size(58, 17);
            this.admin_rad_btn.TabIndex = 13;
            this.admin_rad_btn.TabStop = true;
            this.admin_rad_btn.Text = "admin";
            this.admin_rad_btn.UseVisualStyleBackColor = false;
            this.admin_rad_btn.CheckedChanged += new System.EventHandler(this.radioButton1_CheckedChanged);
            // 
            // next_btn
            // 
            this.next_btn.Location = new System.Drawing.Point(258, 476);
            this.next_btn.Name = "next_btn";
            this.next_btn.Size = new System.Drawing.Size(75, 23);
            this.next_btn.TabIndex = 12;
            this.next_btn.Text = "Next";
            this.next_btn.UseVisualStyleBackColor = true;
            this.next_btn.Click += new System.EventHandler(this.next_btn_Click);
            // 
            // back_btn
            // 
            this.back_btn.Location = new System.Drawing.Point(55, 475);
            this.back_btn.Name = "back_btn";
            this.back_btn.Size = new System.Drawing.Size(99, 23);
            this.back_btn.TabIndex = 11;
            this.back_btn.Text = "Back";
            this.back_btn.UseVisualStyleBackColor = true;
            this.back_btn.Click += new System.EventHandler(this.back_btn_Click);
            // 
            // location_combo
            // 
            this.location_combo.AutoSize = true;
            this.location_combo.BackColor = System.Drawing.Color.Transparent;
            this.location_combo.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.location_combo.Location = new System.Drawing.Point(45, 376);
            this.location_combo.Name = "location_combo";
            this.location_combo.Size = new System.Drawing.Size(94, 25);
            this.location_combo.TabIndex = 10;
            this.location_combo.Text = "Location";
            this.location_combo.Click += new System.EventHandler(this.location_combo_Click);
            // 
            // phone_label
            // 
            this.phone_label.AutoSize = true;
            this.phone_label.BackColor = System.Drawing.Color.Transparent;
            this.phone_label.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.phone_label.Location = new System.Drawing.Point(45, 335);
            this.phone_label.Name = "phone_label";
            this.phone_label.Size = new System.Drawing.Size(90, 25);
            this.phone_label.TabIndex = 9;
            this.phone_label.Text = "phone #";
            // 
            // gender_label
            // 
            this.gender_label.AutoSize = true;
            this.gender_label.BackColor = System.Drawing.Color.Transparent;
            this.gender_label.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.gender_label.Location = new System.Drawing.Point(45, 293);
            this.gender_label.Name = "gender_label";
            this.gender_label.Size = new System.Drawing.Size(83, 25);
            this.gender_label.TabIndex = 8;
            this.gender_label.Text = "Gender";
            // 
            // ID_lbl
            // 
            this.ID_lbl.AutoSize = true;
            this.ID_lbl.BackColor = System.Drawing.Color.Transparent;
            this.ID_lbl.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ID_lbl.Location = new System.Drawing.Point(60, 261);
            this.ID_lbl.Name = "ID_lbl";
            this.ID_lbl.Size = new System.Drawing.Size(33, 25);
            this.ID_lbl.TabIndex = 7;
            this.ID_lbl.Text = "ID";
            // 
            // name_lbl
            // 
            this.name_lbl.AutoSize = true;
            this.name_lbl.BackColor = System.Drawing.Color.Transparent;
            this.name_lbl.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.name_lbl.Location = new System.Drawing.Point(50, 221);
            this.name_lbl.Name = "name_lbl";
            this.name_lbl.Size = new System.Drawing.Size(68, 25);
            this.name_lbl.TabIndex = 6;
            this.name_lbl.Text = "Name";
            // 
            // comboBox1
            // 
            this.comboBox1.BackColor = System.Drawing.Color.Silver;
            this.comboBox1.FormattingEnabled = true;
            this.comboBox1.Location = new System.Drawing.Point(155, 376);
            this.comboBox1.Name = "comboBox1";
            this.comboBox1.Size = new System.Drawing.Size(165, 21);
            this.comboBox1.TabIndex = 5;
            // 
            // phone_textbox
            // 
            this.phone_textbox.BackColor = System.Drawing.Color.Silver;
            this.phone_textbox.Location = new System.Drawing.Point(158, 335);
            this.phone_textbox.Name = "phone_textbox";
            this.phone_textbox.Size = new System.Drawing.Size(165, 20);
            this.phone_textbox.TabIndex = 4;
            // 
            // female_rb
            // 
            this.female_rb.AutoSize = true;
            this.female_rb.BackColor = System.Drawing.Color.Transparent;
            this.female_rb.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.female_rb.Location = new System.Drawing.Point(258, 293);
            this.female_rb.Name = "female_rb";
            this.female_rb.Size = new System.Drawing.Size(62, 17);
            this.female_rb.TabIndex = 3;
            this.female_rb.TabStop = true;
            this.female_rb.Text = "female";
            this.female_rb.UseVisualStyleBackColor = false;
            // 
            // male_rb
            // 
            this.male_rb.AutoSize = true;
            this.male_rb.BackColor = System.Drawing.Color.Transparent;
            this.male_rb.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.male_rb.Location = new System.Drawing.Point(158, 293);
            this.male_rb.Name = "male_rb";
            this.male_rb.Size = new System.Drawing.Size(51, 17);
            this.male_rb.TabIndex = 2;
            this.male_rb.TabStop = true;
            this.male_rb.Text = "male";
            this.male_rb.UseVisualStyleBackColor = false;
            this.male_rb.CheckedChanged += new System.EventHandler(this.male_rb_CheckedChanged);
            // 
            // id_textbox
            // 
            this.id_textbox.BackColor = System.Drawing.Color.Silver;
            this.id_textbox.Location = new System.Drawing.Point(158, 261);
            this.id_textbox.Name = "id_textbox";
            this.id_textbox.Size = new System.Drawing.Size(165, 20);
            this.id_textbox.TabIndex = 1;
            // 
            // name_textbox
            // 
            this.name_textbox.BackColor = System.Drawing.Color.Silver;
            this.name_textbox.Location = new System.Drawing.Point(158, 224);
            this.name_textbox.Name = "name_textbox";
            this.name_textbox.Size = new System.Drawing.Size(165, 20);
            this.name_textbox.TabIndex = 0;
            // 
            // sign_up_new_user
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(494, 526);
            this.Controls.Add(this.panel1);
            this.Name = "sign_up_new_user";
            this.Text = "sign_up_new_user";
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.guna2PictureBox1)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Button back_btn;
        private System.Windows.Forms.Label location_combo;
        private System.Windows.Forms.Label phone_label;
        private System.Windows.Forms.Label gender_label;
        private System.Windows.Forms.Label ID_lbl;
        private System.Windows.Forms.Label name_lbl;
        private System.Windows.Forms.ComboBox comboBox1;
        private System.Windows.Forms.TextBox phone_textbox;
        private System.Windows.Forms.RadioButton female_rb;
        private System.Windows.Forms.RadioButton male_rb;
        private System.Windows.Forms.TextBox id_textbox;
        private System.Windows.Forms.TextBox name_textbox;
        private System.Windows.Forms.Button next_btn;
        private System.Windows.Forms.RadioButton user_rad_btn;
        private System.Windows.Forms.RadioButton admin_rad_btn;
        private Guna.UI2.WinForms.Guna2PictureBox guna2PictureBox1;
        private System.Windows.Forms.Label user_type_lbl;
        private Guna.UI2.WinForms.Guna2TextBox guna2TextBox1;
    }
}